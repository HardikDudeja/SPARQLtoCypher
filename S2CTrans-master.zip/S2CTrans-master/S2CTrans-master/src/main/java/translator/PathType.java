package translator;

public enum PathType {
    ZeroOrMore,
    OneOrMore,
    Specific,
    Inverse,
    Normal
}

